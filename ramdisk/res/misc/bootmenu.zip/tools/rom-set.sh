#!/sbin/busybox sh

# Ketut P. Kumajaya, May 2013

/sbin/busybox echo -n $1 > /.secondrom/media/.defaultrom
