#!/sbin/busybox sh

# Ketut P. Kumajaya, May 2013

SECONDROM=1
/sbin/busybox [ -f /.secondrom/media/.secondrom/system.img ] || SECONDROM=0

exit $SECONDROM
